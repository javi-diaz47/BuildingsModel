/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Graficos;

import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 *
 * @author FELIX M. MARRUGO
 */
public class Label {
    int id;
    public void CreateLabel(JPanel Panelp, ArrayList<JLabel>ArregloJLabel, int id, int x, int y){
        Panelp.setLayout(null);
        JLabel label = new JLabel("q", SwingConstants.CENTER);
        label.setText(String.valueOf(id));
        Panelp.add(label);
        label.setBackground(Color.yellow);
        label.setOpaque(true);
        label.setBounds(x+8, y+8, 25,25);
        
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    
}
