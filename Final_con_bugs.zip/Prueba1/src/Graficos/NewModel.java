package Graficos;

public class NewModel {
    public void NewModel(){
        Ventana NewModel = new Ventana(); 
        NewModel.setVisible(true);
    }
}
