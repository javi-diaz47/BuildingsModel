package Graficos;

/**
 *
 * @author edalr
 */
public class NewModel {
    public void NewModel(){
        Ventana NewModel = new Ventana(); 
        NewModel.setVisible(true);
      
    }
}
