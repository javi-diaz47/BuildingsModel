This is the project with the teacher modifications
